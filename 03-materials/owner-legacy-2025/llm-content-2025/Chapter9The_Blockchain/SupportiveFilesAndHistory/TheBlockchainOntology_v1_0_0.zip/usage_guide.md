# Blockchain Technology Ontology - Usage Guide

**Version**: 1.0.0  
**Date**: December 21, 2025  
**Audience**: Developers, Researchers, Educators

---

## Quick Start

### Installation & Loading

**Prerequisites**:
- Python 3.7+ (for RDFLib examples)
- Java 8+ (for Protégé)
- Basic knowledge of RDF/SPARQL

**Option 1: Python with RDFLib**

```bash
# Install RDFLib
pip install rdflib

# Download ontology
wget http://example.org/blockchain/v1.0.0/blockchain_ontology_v1_0_0.ttl
```

```python
from rdflib import Graph

# Load ontology
g = Graph()
g.parse("blockchain_ontology_v1_0_0.ttl", format="turtle")

print(f"Loaded {len(g)} triples successfully!")
# Output: Loaded 989 triples successfully!
```

**Option 2: Protégé (GUI)**

1. Download Protégé: https://protege.stanford.edu/
2. Open Protégé
3. File → Open → Select `blockchain_ontology_v1_0_0.ttl`
4. Browse classes, properties, and instances visually

**Option 3: Apache Jena (Java)**

```java
import org.apache.jena.rdf.model.*;

Model model = ModelFactory.createDefaultModel();
model.read("blockchain_ontology_v1_0_0.ttl", "TURTLE");

System.out.println("Triples: " + model.size());
```

---

## Basic Operations

### 1. Querying Classes

**Find all block types:**

```python
from rdflib import Namespace, RDF, RDFS

BC = Namespace("http://example.org/blockchain#")

query = """
PREFIX bc: <http://example.org/blockchain#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?blockType ?label
WHERE {
    ?blockType rdfs:subClassOf+ bc:Block .
    ?blockType rdfs:label ?label .
}
"""

results = g.query(query)
for row in results:
    print(f"Block Type: {row.label}")
```

**Output**:
```
Block Type: Genesis Block
Block Type: Regular Block
Block Type: Orphan Block
Block Type: Stale Block
```

### 2. Exploring Properties

**Get all properties of Block class:**

```sparql
PREFIX bc: <http://example.org/blockchain#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?property ?label ?range
WHERE {
    ?property rdfs:domain bc:Block .
    ?property rdfs:label ?label .
    OPTIONAL { ?property rdfs:range ?range }
}
```

**Output**:
```
blockSize → xsd:nonNegativeInteger
blockHeight → xsd:nonNegativeInteger
blockWeight → xsd:nonNegativeInteger
transactionCounter → xsd:nonNegativeInteger
```

### 3. Retrieving Definitions

**Get definition of SegWit:**

```python
query = """
PREFIX bc: <http://example.org/blockchain#>
PREFIX skos: <http://www.w3.org/2004/02/skos/core#>

SELECT ?definition ?comment ?example
WHERE {
    bc:SegregatedWitness skos:definition ?definition .
    OPTIONAL { bc:SegregatedWitness rdfs:comment ?comment }
    OPTIONAL { bc:SegregatedWitness skos:example ?example }
}
"""

results = g.query(query)
for row in results:
    print(f"Definition: {row.definition}")
    if row.comment:
        print(f"Comment: {row.comment}")
    if row.example:
        print(f"Example: {row.example}")
```

---

## Common Use Cases

### Use Case 1: Educational Platform

**Goal**: Display blockchain concepts for students

```python
class BlockchainEducationAPI:
    def __init__(self, ontology_graph):
        self.g = ontology_graph
        self.BC = Namespace("http://example.org/blockchain#")
    
    def get_concept_info(self, concept_name):
        """Retrieve full information about a concept"""
        concept_uri = self.BC[concept_name]
        
        query = f"""
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
        
        SELECT ?label ?definition ?comment ?example ?altLabel
        WHERE {{
            <{concept_uri}> rdfs:label ?label .
            <{concept_uri}> skos:definition ?definition .
            OPTIONAL {{ <{concept_uri}> rdfs:comment ?comment }}
            OPTIONAL {{ <{concept_uri}> skos:example ?example }}
            OPTIONAL {{ <{concept_uri}> skos:altLabel ?altLabel }}
        }}
        """
        
        results = list(self.g.query(query))
        if results:
            return {
                'label': str(results[0].label),
                'definition': str(results[0].definition),
                'comment': str(results[0].comment) if results[0].comment else None,
                'example': str(results[0].example) if results[0].example else None,
                'alternative_labels': [str(r.altLabel) for r in results if r.altLabel]
            }
        return None
    
    def get_related_concepts(self, concept_name):
        """Find parent, children, and related concepts"""
        concept_uri = self.BC[concept_name]
        
        # Query for parent classes
        parent_query = f"""
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        SELECT ?parent ?label WHERE {{
            <{concept_uri}> rdfs:subClassOf ?parent .
            ?parent rdfs:label ?label .
        }}
        """
        
        # Query for child classes
        child_query = f"""
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        SELECT ?child ?label WHERE {{
            ?child rdfs:subClassOf <{concept_uri}> .
            ?child rdfs:label ?label .
        }}
        """
        
        parents = [str(r.label) for r in self.g.query(parent_query)]
        children = [str(r.label) for r in self.g.query(child_query)]
        
        return {
            'parents': parents,
            'children': children
        }

# Usage
edu_api = BlockchainEducationAPI(g)
info = edu_api.get_concept_info("Blockchain")
print(f"Teaching: {info['label']}")
print(f"Definition: {info['definition']}")

related = edu_api.get_related_concepts("Block")
print(f"Types of blocks: {related['children']}")
```

### Use Case 2: Blockchain Validator

**Goal**: Validate blockchain implementation against ontology

```python
class BlockchainValidator:
    def __init__(self, ontology_graph):
        self.g = ontology_graph
        self.BC = Namespace("http://example.org/blockchain#")
    
    def validate_block_header(self, header_data):
        """Validate block header has all required fields"""
        # Query ontology for required BlockHeader properties
        query = """
        PREFIX bc: <http://example.org/blockchain#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        
        SELECT ?property ?label
        WHERE {
            ?property rdfs:domain bc:BlockHeader .
            ?property rdfs:label ?label .
        }
        """
        
        required_fields = []
        for row in self.g.query(query):
            field_name = str(row.label).replace(' ', '')
            field_name = field_name[0].lower() + field_name[1:]  # camelCase
            required_fields.append(field_name)
        
        # Validate input
        errors = []
        for field in required_fields:
            if field not in header_data:
                errors.append(f"Missing required field: {field}")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'required_fields': required_fields
        }
    
    def validate_property_datatype(self, property_name, value):
        """Validate property value matches ontology datatype"""
        query = f"""
        PREFIX bc: <http://example.org/blockchain#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        
        SELECT ?range
        WHERE {{
            bc:{property_name} rdfs:range ?range .
        }}
        """
        
        results = list(self.g.query(query))
        if results:
            expected_type = str(results[0].range)
            # Implement type checking logic
            return True  # Simplified
        return False

# Usage
validator = BlockchainValidator(g)

header = {
    'version': 2,
    'previousBlockHash': '0x123...',
    'merkleRoot': '0xabc...',
    'timestamp': '2025-12-21T10:00:00Z',
    'difficultyTarget': '0x1d00ffff',
    'nonce': 123456
}

result = validator.validate_block_header(header)
if result['valid']:
    print("✓ Block header valid!")
else:
    print("✗ Validation errors:")
    for error in result['errors']:
        print(f"  - {error}")
```

### Use Case 3: Documentation Generator

**Goal**: Auto-generate blockchain documentation

```python
class DocumentationGenerator:
    def __init__(self, ontology_graph):
        self.g = ontology_graph
    
    def generate_class_documentation(self, class_uri):
        """Generate markdown documentation for a class"""
        query = f"""
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
        
        SELECT ?label ?definition ?comment ?example
        WHERE {{
            <{class_uri}> rdfs:label ?label .
            <{class_uri}> skos:definition ?definition .
            OPTIONAL {{ <{class_uri}> rdfs:comment ?comment }}
            OPTIONAL {{ <{class_uri}> skos:example ?example }}
        }}
        """
        
        results = list(self.g.query(query))
        if results:
            r = results[0]
            doc = f"## {r.label}\n\n"
            doc += f"**Definition**: {r.definition}\n\n"
            if r.comment:
                doc += f"**Notes**: {r.comment}\n\n"
            if r.example:
                doc += f"**Example**: {r.example}\n\n"
            return doc
        return ""
    
    def generate_hierarchy_doc(self, root_class):
        """Generate hierarchical documentation"""
        # Recursive hierarchy traversal
        # Format as markdown tree
        pass

# Usage
doc_gen = DocumentationGenerator(g)
BC = Namespace("http://example.org/blockchain#")
markdown = doc_gen.generate_class_documentation(BC.SegregatedWitness)
print(markdown)
```

### Use Case 4: Research Analytics

**Goal**: Analyze protocol evolution over time

```python
class ProtocolEvolutionAnalyzer:
    def __init__(self, ontology_graph):
        self.g = ontology_graph
    
    def get_upgrade_timeline(self):
        """Retrieve all protocol upgrades chronologically"""
        query = """
        PREFIX bc: <http://example.org/blockchain#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        
        SELECT ?upgrade ?label ?date ?blockHeight ?bipNumber
        WHERE {
            ?upgrade rdfs:subClassOf+ bc:ProtocolUpgrade .
            ?upgrade rdfs:label ?label .
            OPTIONAL { ?upgrade bc:activationDate ?date }
            OPTIONAL { ?upgrade bc:activationBlockHeight ?blockHeight }
            OPTIONAL { ?upgrade bc:bipNumber ?bipNumber }
        }
        ORDER BY ?date
        """
        
        timeline = []
        for row in self.g.query(query):
            timeline.append({
                'name': str(row.label),
                'date': str(row.date) if row.date else 'Unknown',
                'block_height': int(row.blockHeight) if row.blockHeight else None,
                'bip': str(row.bipNumber) if row.bipNumber else None
            })
        
        return timeline
    
    def compare_signature_schemes(self):
        """Compare ECDSA vs Schnorr"""
        query = """
        PREFIX bc: <http://example.org/blockchain#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
        
        SELECT ?scheme ?label ?definition
        WHERE {
            ?scheme rdfs:subClassOf bc:SignatureScheme .
            ?scheme rdfs:label ?label .
            ?scheme skos:definition ?definition .
        }
        """
        
        schemes = {}
        for row in self.g.query(query):
            schemes[str(row.label)] = str(row.definition)
        
        return schemes

# Usage
analyzer = ProtocolEvolutionAnalyzer(g)
timeline = analyzer.get_upgrade_timeline()

print("Protocol Evolution Timeline:")
for upgrade in timeline:
    print(f"{upgrade['date']}: {upgrade['name']} ({upgrade['bip']})")
```

---

## Advanced Queries

### Query 1: Find All Concepts Introduced in Taproot

```sparql
PREFIX bc: <http://example.org/blockchain#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?concept ?label
WHERE {
    ?concept bc:introducedIn bc:TaprootUpgrade .
    ?concept rdfs:label ?label .
}
```

**Results**:
- Schnorr Signatures
- MAST
- Pay-to-Taproot
- Tapscript

### Query 2: Trace Block Ancestry Chain

```sparql
PREFIX bc: <http://example.org/blockchain#>

SELECT ?block ?parent ?height
WHERE {
    ?block bc:hasParentBlock ?parent .
    ?block bc:blockHeight ?height .
}
ORDER BY ?height
LIMIT 100
```

### Query 3: Get All Network Types

```sparql
PREFIX bc: <http://example.org/blockchain#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX skos: <http://www.w3.org/2004/02/skos/core#>

SELECT ?network ?label ?definition
WHERE {
    ?network rdfs:subClassOf+ bc:BlockchainNetwork .
    ?network rdfs:label ?label .
    ?network skos:definition ?definition .
}
```

### Query 4: Find Concepts with Examples

```sparql
PREFIX bc: <http://example.org/blockchain#>
PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

SELECT ?concept ?label ?example
WHERE {
    ?concept skos:example ?example .
    ?concept rdfs:label ?label .
}
```

---

## Integration Patterns

### Pattern 1: REST API Wrapper

```python
from flask import Flask, jsonify
from rdflib import Graph, Namespace

app = Flask(__name__)

# Load ontology at startup
g = Graph()
g.parse("blockchain_ontology_v1_0_0.ttl", format="turtle")
BC = Namespace("http://example.org/blockchain#")

@app.route('/api/concept/<concept_name>')
def get_concept(concept_name):
    """REST endpoint for concept information"""
    # Query ontology
    # Return JSON
    pass

@app.route('/api/hierarchy/<root_class>')
def get_hierarchy(root_class):
    """REST endpoint for class hierarchy"""
    # Query subclasses
    # Return tree structure
    pass

if __name__ == '__main__':
    app.run(debug=True)
```

### Pattern 2: GraphQL Schema Generation

```python
import graphene
from rdflib import Graph

class BlockchainConcept(graphene.ObjectType):
    label = graphene.String()
    definition = graphene.String()
    examples = graphene.List(graphene.String)
    
class Query(graphene.ObjectType):
    concept = graphene.Field(BlockchainConcept, name=graphene.String())
    
    def resolve_concept(self, info, name):
        # Query RDF graph
        # Return concept data
        pass

schema = graphene.Schema(query=Query)
```

---

## Troubleshooting

### Issue: Ontology Won't Load

**Problem**: `rdflib.exceptions.ParserError`

**Solution**:
```python
# Check file encoding
with open('blockchain_ontology_v1_0_0.ttl', 'r', encoding='utf-8') as f:
    content = f.read()

# Verify Turtle syntax
from rdflib import Graph
g = Graph()
try:
    g.parse(data=content, format='turtle')
    print("✓ Valid Turtle syntax")
except Exception as e:
    print(f"✗ Syntax error: {e}")
```

### Issue: Query Returns No Results

**Problem**: SPARQL query returns empty set

**Solution**:
```python
# Check namespace prefix
print("Namespaces in graph:")
for prefix, namespace in g.namespaces():
    print(f"{prefix}: {namespace}")

# Use correct prefix in query
query = """
PREFIX bc: <http://example.org/blockchain#>  # Must match ontology namespace
SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 10
"""
```

### Issue: Performance Slow with Large Datasets

**Problem**: Queries take too long

**Solution**:
```python
# Use indexes
from rdflib.plugins.stores import sparqlstore

# Or use triple store
# from rdflib import ConjunctiveGraph
# g = ConjunctiveGraph('SPARQLUpdateStore')
```

---

## Best Practices

### 1. Querying

✓ **DO**: Use LIMIT for large result sets
```sparql
SELECT ?s ?p ?o WHERE { ?s ?p ?o } LIMIT 100
```

✗ **DON'T**: Query without LIMIT on production data
```sparql
SELECT ?s ?p ?o WHERE { ?s ?p ?o }  # Could return millions
```

### 2. Extending the Ontology

✓ **DO**: Follow existing patterns
```turtle
:MyNewConcept a owl:Class ;
    rdfs:label "My New Concept"@en ;
    rdfs:subClassOf :AppropriateParent ;
    skos:definition "Precise definition"@en ;
    :sourceEvidence [ ... ] .
```

✗ **DON'T**: Break naming conventions
```turtle
:my_new_concept a owl:Class ;  # Wrong: use PascalCase
    rdfs:label "concept" ;      # Wrong: needs @en tag
```

### 3. Validation

✓ **DO**: Validate changes
```python
# After modifications
from rdflib import Graph
g = Graph()
g.parse("modified_ontology.ttl", format="turtle")
print(f"✓ Valid: {len(g)} triples")
```

### 4. Version Management

✓ **DO**: Update version metadata
```turtle
<http://example.org/blockchain> owl:versionInfo "1.1.0" ;
    owl:versionIRI <http://example.org/blockchain/v1.1.0> ;
    dcterms:modified "2026-01-15"^^xsd:date .
```

---

## Examples Repository

Complete working examples available at:
```
/examples/
├── education_api.py          # Educational platform integration
├── validator.py              # Blockchain validation tool
├── doc_generator.py          # Documentation automation
├── analytics.py              # Research analysis tools
├── rest_api.py               # REST API wrapper
└── graphql_schema.py         # GraphQL integration
```

---

## Support & Community

**Documentation**: See `blockchain_ontology_documentation.md`  
**Quality Report**: See `quality_report.md`  
**Issues**: [To be created]  
**Discussions**: [To be created]

---

## License

Creative Commons Attribution 4.0 International (CC BY 4.0)

You are free to:
- Share — copy and redistribute
- Adapt — remix, transform, and build upon

Under the following terms:
- Attribution — give appropriate credit

---

**Guide Version**: 1.0  
**Last Updated**: December 21, 2025  
**For Ontology**: v1.0.0
