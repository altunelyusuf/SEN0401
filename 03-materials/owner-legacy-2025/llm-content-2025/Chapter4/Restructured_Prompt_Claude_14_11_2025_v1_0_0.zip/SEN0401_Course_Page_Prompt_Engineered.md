# PROMPT: Interactive Course Page Development for SEN0401 - Blockchain Technology
## Phased Ontology-Driven Educational Content Generation

---

## 🎯 ROLE & CONTEXT

<role>
You are an expert educational content developer and web engineer specializing in:
- Ontology-driven content generation and knowledge representation
- Interactive learning experience design
- Blockchain technology education
- Modern web development with HTML5, CSS3, JavaScript
- Gamification and adaptive learning systems
</role>

<context>
**Course**: SEN0401 - Special Topics in Software Engineering (Blockchain)  
**Institution**: Istanbul Kültür University, Computer Engineering Department  
**Target Audience**: University students studying software engineering  
**Primary Content Source**: Chapter 4 (Keys & Addresses) from Antonopoulos 2027  
**Instructional Approach**: Interactive, gamified, visually engaging with hands-on coding
</context>

---

## 📚 KNOWLEDGE RESOURCES

<resources>
You have access to the following resources:

1. **Content Source**:
   - `Chapter_4_Keys_Addresses_Antonopoulos_2027.docx` - Primary educational content on blockchain keys and addresses

2. **Ontology Frameworks**:
   - `Ontology_for_Research_in_Academy_and_Industry_Claude_26_10_2025.ttl` - Research methodology ontology for academic content development
   - `Ontology_for_Report_Generation_v1_0_0.ttl` - Structured report generation framework
   - `WebPageConstruction_Ontology_v1_0_0_ENHANCED.ttl` - Web page architecture and component specifications

3. **Quality Standards**:
   - OQC (Ontology Quality Control) metrics embedded in ontologies
   - WCAG 2.1 AA accessibility standards
   - Modern web performance benchmarks
</resources>

---

## 🎓 PROJECT OBJECTIVE

Create a comprehensive, interactive, and engaging HTML-based course page that:
- Teaches blockchain keys and addresses concepts completely and accurately
- Engages students through gamification, interactivity, and visual appeal
- Provides hands-on coding experiences
- Assesses learning through interactive quizzes and games
- Achieves exceptional quality metrics across all evaluation dimensions

---

## 📊 SUCCESS CRITERIA

<quality_metrics>
The final deliverable must achieve:

**Content Quality** (Target: 100/100):
- ✓ Correctness: 100% technically accurate blockchain information
- ✓ Completeness: 100% coverage of Chapter 4 content with no omissions
- ✓ Comprehensiveness: Full depth with examples, edge cases, and real-world applications
- ✓ Cohesiveness: Logical flow with clear connections between concepts

**Readability & Understanding** (Target: 100/100):
- ✓ Readability: Clear, concise language appropriate for university students
- ✓ Understandability: Complex concepts explained with analogies, examples, and visualizations
- ✓ Modularity: Well-organized sections that can be studied independently

**User Experience** (Target: 98+/100):
- ✓ Usability: Intuitive navigation, clear information architecture
- ✓ User Experience: Engaging interactions, smooth animations, responsive design
- ✓ Aesthetics: Visually appealing with vibrant colors, modern design, professional appearance
- ✓ Accessibility: WCAG 2.1 AA compliant, keyboard navigable, screen reader friendly

**Interactive Elements**:
- ✓ 10+ embedded digital learning games
- ✓ Kahoot-style quiz questions (minimum 20 questions)
- ✓ Interactive coding exercises (minimum 8 examples)
- ✓ Animations, diagrams, charts, and visualizations
</quality_metrics>

---

## 🔄 EXECUTION PHASES

Execute this project in **5 distinct phases**, each with specific deliverables and token management.

---

### ⚙️ PHASE 1: Research & Content Analysis

<phase_1>
**Objective**: Extract, analyze, and structure the source content using ontology-driven research methodology.

**Tasks**:
1. **Content Extraction**:
   - Read and parse `Chapter_4_Keys_Addresses_Antonopoulos_2027.docx` completely
   - Identify all key concepts, definitions, algorithms, and examples
   - Extract code snippets, diagrams, and technical specifications

2. **Ontology-Driven Research**:
   - Apply `Ontology_for_Research_in_Academy_and_Industry_Claude_26_10_2025.ttl` to:
     * Identify research questions and learning objectives
     * Map domain concepts to academic research frameworks
     * Define knowledge dependencies and prerequisite relationships
     * Establish content taxonomy

3. **Content Structuring**:
   - Create hierarchical outline of all topics
   - Define learning objectives for each section
   - Identify opportunities for interactive elements
   - List prerequisite knowledge requirements

**Deliverable**: 
`Phase1_Content_Analysis_Report.md` containing:
- Complete content taxonomy (hierarchical outline)
- Learning objectives mapped to content sections
- Key concepts dictionary
- Interactive element opportunities matrix
- Knowledge dependency graph

**Success Validation**:
- All content from Chapter 4 is identified and categorized
- Clear learning objectives for each section
- Interactive opportunities identified for each major concept

</phase_1>

**🔚 PHASE 1 CHECKPOINT**: Provide download link for Phase 1 deliverable and await user approval to proceed.

---

### 📝 PHASE 2: Report Generation

<phase_2>
**Objective**: Generate a comprehensive pedagogical report using the Report Generation Ontology.

**Tasks**:
1. **Apply Report Generation Ontology**:
   - Use `Ontology_for_Report_Generation_v1_0_0.ttl` to structure the report
   - Map content sections to report structure
   - Define report metadata and versioning

2. **Report Content Development**:
   - **Executive Summary**: Course overview and learning outcomes
   - **Introduction Section**: Blockchain context and importance of keys/addresses
   - **Core Concepts**: Each major topic with:
     * Detailed explanations
     * Mathematical formulations
     * Real-world examples
     * Common pitfalls and misconceptions
   - **Technical Deep Dives**: Algorithms, protocols, and implementations
   - **Practical Applications**: Use cases and industry practices
   - **Assessment Strategy**: How learning will be evaluated
   - **References**: Additional resources and further reading

3. **Pedagogical Enhancements**:
   - Add "Real-World Connection" sections
   - Include "Common Misconceptions" callouts
   - Provide "Pro Tips" for advanced learners
   - Design "Think About It" reflection prompts

**Deliverable**: 
`Phase2_Pedagogical_Report.md` containing:
- Structured comprehensive report (15-25 pages)
- All content sections with pedagogical enhancements
- Visual content placeholders and specifications
- Assessment question bank (50+ questions)
- Interactive exercise specifications

**Success Validation**:
- Report covers 100% of Chapter 4 content
- Each section has clear learning objectives
- Pedagogical enhancements integrated throughout
- Ready for web page transformation

</phase_2>

**🔚 PHASE 2 CHECKPOINT**: Provide download link for Phase 2 deliverable and await user approval to proceed.

---

### 🎨 PHASE 3: Web Page Architecture & Design System

<phase_3>
**Objective**: Design the web page architecture, visual system, and interactive components using the Web Page Construction Ontology.

**Tasks**:
1. **Apply Web Page Construction Ontology**:
   - Use `WebPageConstruction_Ontology_v1_0_0_ENHANCED.ttl` to define:
     * Page structure and layout system
     * Component hierarchy
     * Navigation patterns
     * Content rendering strategies

2. **Design System Specification**:
   - **Color Palette**:
     * Primary: Vibrant blue (#2563EB) - trust, technology
     * Secondary: Energetic purple (#7C3AED) - innovation
     * Accent: Success green (#10B981) - learning achievements
     * Warning: Amber (#F59E0B) - important concepts
     * Minimal black, maximum color vibrancy
   
   - **Typography System**:
     * Headings: Modern sans-serif (e.g., Inter, Poppins)
     * Body: Readable serif or optimized sans-serif
     * Code: Monospace (e.g., JetBrains Mono, Fira Code)
     * Scale: Responsive type scale (16px base, 1.25 ratio)

   - **Layout System**:
     * Responsive grid: Mobile-first, breakpoints at 640px, 768px, 1024px, 1280px
     * Max content width: 1280px
     * Spacing scale: 4px base unit
     * Card-based component system

3. **Navigation Design**:
   - **Sticky Top Menu** (always visible):
     * Course title and logo
     * Section navigation with smooth scroll
     * Progress indicator
     * Theme toggle (light/dark mode)
     * Search functionality
   
   - **Section Menu**:
     * Expandable/collapsible sidebar
     * Current section highlighting
     * Progress badges
     * Quick jump links

4. **Interactive Component Specifications**:
   
   - **Game #1-3**: Concept Matching & Memory Games
     * Drag-and-drop key concept matching
     * Blockchain memory card game
     * Terminology matching challenges
   
   - **Game #4-6**: Simulation & Visualization Games
     * Interactive key generation simulator
     * Address derivation step-by-step visualizer
     * Cryptographic signing/verification simulator
   
   - **Game #7-10**: Challenge & Assessment Games
     * Code debugging challenges
     * Security vulnerability identification
     * Real-world scenario problem-solving
     * Speed challenge: key/address operations
   
   - **Quiz System**:
     * Kahoot-style interface
     * Multiple choice, true/false, fill-in-blank
     * Immediate feedback with explanations
     * Score tracking and leaderboard
     * 20+ questions across difficulty levels
   
   - **Coding Exercises**:
     * Embedded code editor (Monaco or CodeMirror)
     * 8+ exercises covering all major concepts
     * Auto-validation with test cases
     * Progressive hints system
     * Solution reveal option

5. **Animation & Visual Specifications**:
   - Scroll-triggered animations (fade-in, slide-in)
   - Interactive diagrams (SVG with JavaScript)
   - Data flow animations for blockchain operations
   - Hover effects and micro-interactions
   - Loading states and progress indicators

**Deliverable**: 
`Phase3_Architecture_Design_Spec.md` containing:
- Complete architecture diagram
- Design system documentation (colors, typography, spacing)
- Component library specifications
- Navigation system details
- All 10 game specifications with mechanics
- Quiz system specification
- Coding exercise framework specification
- Animation and interaction catalog

**Success Validation**:
- Architecture aligned with Web Page Construction Ontology
- Design system is complete and modern
- All interactive components are specified in detail
- Ready for implementation

</phase_3>

**🔚 PHASE 3 CHECKPOINT**: Provide download link for Phase 3 deliverable and await user approval to proceed.

---

### 💻 PHASE 4: HTML/CSS/JavaScript Implementation (Part 1)

<phase_4>
**Objective**: Implement the core HTML structure, CSS styling, and foundational JavaScript functionality.

**Tasks**:
1. **HTML Structure**:
   - Semantic HTML5 with proper heading hierarchy
   - Accessibility attributes (ARIA labels, roles, landmarks)
   - Meta tags for SEO and Open Graph
   - Structured data (JSON-LD for educational content)

2. **CSS Styling**:
   - Modern CSS with custom properties (CSS variables)
   - Responsive design with mobile-first approach
   - CSS Grid and Flexbox layouts
   - Animations and transitions
   - Dark mode support
   - Print styles

3. **Core JavaScript**:
   - Sticky navigation implementation
   - Smooth scrolling
   - Progress tracking
   - Theme toggle
   - Local storage for user preferences
   - Intersection Observer for scroll animations

4. **Content Integration**:
   - Integrate all content from Phase 2 report
   - Format code snippets with syntax highlighting
   - Create placeholder sections for games and quizzes
   - Add all diagrams and visualizations

**Technical Requirements**:
- Valid HTML5, CSS3, ES6+ JavaScript
- No framework dependencies (vanilla JS preferred)
- Progressive enhancement approach
- Performance optimized (< 3s load time)
- Mobile responsive (works on screens 320px+)

**Deliverable**: 
`Phase4_Core_Implementation.html` (single HTML file) containing:
- Complete HTML structure with all content
- Embedded CSS (in `<style>` tags)
- Core JavaScript functionality
- All static content rendered
- Placeholders for interactive elements

**Success Validation**:
- All content from Phase 2 is present
- Page is fully responsive
- Sticky navigation works perfectly
- Animations are smooth
- Lighthouse score: 90+ for performance, accessibility, best practices

</phase_4>

**🔚 PHASE 4 CHECKPOINT**: Provide download link for Phase 4 deliverable and await user approval to proceed.

---

### 🎮 PHASE 5: Interactive Elements Implementation (Part 2)

<phase_5>
**Objective**: Implement all interactive elements including games, quizzes, and coding exercises.

**Tasks**:
1. **Game Implementation** (10 games):
   - Game #1: Key Concept Drag-and-Drop Matching
   - Game #2: Blockchain Terminology Memory Cards
   - Game #3: Algorithm Sequence Ordering
   - Game #4: Interactive Key Generation Simulator
   - Game #5: Address Derivation Visualizer
   - Game #6: Digital Signature Flow Simulator
   - Game #7: Security Vulnerability Identification
   - Game #8: Code Debugging Challenge
   - Game #9: Real-World Scenario Solver
   - Game #10: Speed Challenge: Operations Race

   **Each game must include**:
   - Clear instructions
   - Score tracking
   - Timer (where appropriate)
   - Visual feedback (correct/incorrect)
   - "Try Again" functionality
   - Achievement badges
   - Educational feedback on completion

2. **Quiz System Implementation**:
   - Kahoot-style interface with vibrant colors
   - Question bank (20+ questions)
   - Question types: Multiple choice, True/False, Fill-in-blank
   - Timer per question
   - Immediate feedback with explanations
   - Score summary
   - Performance analytics
   - Retry functionality

3. **Interactive Coding Exercises** (8+ exercises):
   - Embedded code editor with syntax highlighting
   - Exercise types covering:
     * Key generation implementation
     * Address encoding/decoding
     * Signature creation and verification
     * Hash function implementation
     * Base58/Base58Check encoding
     * HD wallet derivation
     * Multi-signature schemes
     * Practical wallet integration
   
   **Each exercise must include**:
   - Problem description
   - Starter code template
   - Test cases for auto-validation
   - Progressive hint system (3 levels)
   - Solution reveal button
   - Explanation of solution

4. **Visual Enhancements**:
   - Add interactive diagrams using SVG + JavaScript
   - Implement data flow animations
   - Create process visualization tools
   - Add charts and graphs (if applicable)

5. **Final Integration & Polish**:
   - Connect all interactive elements
   - Ensure smooth transitions between sections
   - Test all functionality
   - Optimize performance
   - Final accessibility audit
   - Cross-browser testing notes

**Technical Requirements**:
- All games use pure JavaScript (no game frameworks)
- Code editor: Monaco Editor (CDN) or CodeMirror
- Syntax highlighting: Prism.js or highlight.js
- Animation library: GSAP (optional) or CSS animations
- Chart library: Chart.js or D3.js (if needed)
- All libraries loaded from CDN (no build process)

**Deliverable**: 
`Phase5_Complete_Course_Page.html` - The final, complete, fully functional course page containing:
- All content from previous phases
- All 10 interactive games implemented and tested
- Complete quiz system with 20+ questions
- All 8+ coding exercises implemented
- All visual enhancements
- Polished, production-ready code

**Success Validation**:
- All 10 games are fully functional
- Quiz system works flawlessly
- All coding exercises validate correctly
- Page achieves 98+ on UX metrics
- Page achieves 100 on content quality metrics
- All animations are smooth (60fps)
- Total file size < 500KB (excluding CDN resources)
- Lighthouse score: 95+ across all categories

</phase_5>

**🔚 PHASE 5 CHECKPOINT**: Provide download link for final deliverable.

---

## 🎯 EXECUTION INSTRUCTIONS

<execution_protocol>
**For Each Phase**:

1. **Phase Introduction**: Briefly state what you're about to do
2. **Phase Execution**: Complete all tasks for the phase
3. **Quality Check**: Verify success validation criteria
4. **Deliverable Generation**: Create the specified output file(s)
5. **Checkpoint**: Provide download link and pause for user approval

**Between Phases**:
- Wait for explicit user approval before proceeding to next phase
- If user requests changes, implement them before proceeding
- If user approves, continue to next phase automatically

**Token Management**:
- Each phase designed to fit within token limits
- If approaching limit, complete current phase and checkpoint
- Phase 4 and 5 may be split further if needed

**Communication Style**:
- Be concise but complete
- Use code blocks for code
- Use tables for structured data
- Use headers for organization
- Highlight important points with **bold** or `code`
</execution_protocol>

---

## 📋 ADDITIONAL SPECIFICATIONS

<technical_specifications>
**File Structure** (Single HTML File):
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta tags, title, CDN links -->
    <style>
        /* All CSS here */
    </style>
</head>
<body>
    <!-- All HTML content -->
    
    <script>
        // All JavaScript here
    </script>
</body>
</html>
```

**Required CDN Resources**:
- Font: Google Fonts (Inter, JetBrains Mono)
- Icons: Font Awesome 6 or Heroicons
- Code Editor: Monaco Editor or CodeMirror
- Syntax Highlighting: Prism.js
- (Optional) Animation: GSAP
- (Optional) Charts: Chart.js

**Color Psychology Guidelines**:
- Blue: Trust, stability, technology (primary)
- Purple: Creativity, innovation (secondary)
- Green: Success, growth, correctness (positive feedback)
- Orange/Amber: Attention, important concepts (warnings)
- Red: Errors, critical info (use sparingly)
- Avoid: Heavy black backgrounds, pure white (use off-white/subtle gray)

**Accessibility Requirements**:
- All interactive elements keyboard accessible
- Focus indicators visible
- ARIA labels for screen readers
- Color contrast ratio ≥ 4.5:1 for normal text
- Alt text for all images
- Semantic HTML structure
- Skip to content link

**Performance Requirements**:
- Initial load < 3 seconds
- First Contentful Paint < 1.5 seconds
- Largest Contentful Paint < 2.5 seconds
- Cumulative Layout Shift < 0.1
- Time to Interactive < 3.5 seconds

</technical_specifications>

---

## ✅ FINAL QUALITY ASSURANCE

<quality_assurance>
Before marking the project complete, verify:

**Content Completeness**:
- [ ] All Chapter 4 content is present
- [ ] No sections or concepts omitted
- [ ] All code examples included
- [ ] All diagrams recreated or replaced with better versions

**Interactive Elements**:
- [ ] All 10 games implemented and tested
- [ ] Quiz has 20+ questions with feedback
- [ ] 8+ coding exercises with validation
- [ ] All interactive elements work on mobile

**Visual Design**:
- [ ] Sticky navigation always visible
- [ ] Color scheme is vibrant and joyful
- [ ] Typography is readable and hierarchical
- [ ] Animations are smooth and purposeful
- [ ] Page is visually appealing and modern

**Technical Quality**:
- [ ] Valid HTML5/CSS3/ES6+ code
- [ ] No console errors
- [ ] Works in Chrome, Firefox, Safari, Edge
- [ ] Responsive on all screen sizes
- [ ] Fast loading and smooth scrolling

**Educational Quality**:
- [ ] Content is accurate and complete
- [ ] Explanations are clear and understandable
- [ ] Examples are relevant and helpful
- [ ] Games reinforce learning objectives
- [ ] Quizzes assess understanding effectively

</quality_assurance>

---

## 🚀 BEGIN EXECUTION

Please begin with **PHASE 1: Research & Content Analysis**.

After completing Phase 1:
1. Provide the download link for `Phase1_Content_Analysis_Report.md`
2. Ask: "Phase 1 complete. Review the content analysis and approve to proceed to Phase 2, or request modifications."

**Ready to start?**
